# HOK Ranked – Android APK

WebView app of the **Honor of Kings Ranked System** with a floating
**rank + stars circle** (display over other apps). Tap the circle → back to the app.
Drag it to move it.

## Build in the cloud (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Push to `main` (or open **Actions → Build HOK Ranked APK → Run workflow**).
3. When it's green, open the run → **Artifacts**:
   - `HOK-Ranked-APKs-zip` → one ZIP with all APKs
   - `HOK-Ranked-APKs` → the APKs separately
   - 32-bit: `HOK-Ranked-32bit-armeabi-v7a.apk`
   - 64-bit: `HOK-Ranked-64bit-arm64-v8a.apk`
   - Both: `HOK-Ranked-universal-32bit+64bit.apk`
4. Push a tag like `v1.0.0` to also get a GitHub Release with the files.

## Using the circle
- First launch: allow **Display over other apps** (and notifications on Android 13+).
- Press Home / switch apps → the circle appears showing rank name + stars.
- Tap the circle → opens the app. Notification has a **Stop bubble** button.

## Edit the game
The game is `app/src/main/assets/index.html`. If you replace it with a new version,
keep the `<script>` block at the bottom ("Android bridge") – it feeds the circle.
