package com.hok.ranked;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

/**
 * Foreground service that keeps running in the background and draws a small circle
 * (rank + stars) over other apps. Tap the circle -> back to the app. Drag to move.
 */
public class OverlayService extends Service {

    static final String CHANNEL_ID = "hok_overlay";
    static final int NOTIF_ID = 1;
    static final String ACTION_STOP = "com.hok.ranked.STOP";
    static final String PREFS = "hok_overlay_prefs";

    static volatile OverlayService instance;
    static volatile boolean appInForeground = true;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private BubbleView bubble;
    private WindowManager.LayoutParams lp;
    private boolean attached = false;

    // ---------------------------------------------------------------- static helpers

    static boolean canOverlay(Context c) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    }

    static void start(Context c) {
        try {
            Intent i = new Intent(c, OverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Exception ignored) {
        }
    }

    static void setAppForeground(Context c, boolean fg) {
        appInForeground = fg;
        final OverlayService s = instance;
        if (s != null) {
            s.main.post(s::applyVisibility);
        } else if (!fg && canOverlay(c)) {
            start(c);
        }
    }

    /** Called from the JS bridge whenever rank/stars change in the page. */
    static void updateState(Context c, String player, String rank, String hex, int stars, int max) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit().putString("player", player).putString("rank", rank).putString("hex", hex)
                .putInt("stars", stars).putInt("max", max).apply();
        final OverlayService s = instance;
        if (s != null) s.main.post(s::refreshBubble);
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
        buildBubble();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            removeBubble();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
        refreshBubble();
        applyVisibility();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        removeBubble();
        instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---------------------------------------------------------------- notification

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Rank bubble", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;

        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | imm);

        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi;
        if (Build.VERSION.SDK_INT >= 26) {
            stopPi = PendingIntent.getForegroundService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | imm);
        } else {
            stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | imm);
        }

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_star)
                .setContentTitle("HOK Ranked")
                .setContentText("Rank bubble is active. Tap to open the app.")
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(0, "Stop bubble", stopPi);
        return b.build();
    }

    // ---------------------------------------------------------------- bubble

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildBubble() {
        bubble = new BubbleView(this);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int size = dp(84);
        lp = new WindowManager.LayoutParams(size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        lp.x = sp.getInt("x", dp(12));
        lp.y = sp.getInt("y", dp(160));

        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - downRawX;
                        float dy = e.getRawY() - downRawY;
                        if (!moved && Math.abs(dx) < slop && Math.abs(dy) < slop) return true;
                        moved = true;
                        lp.x = Math.max(0, startX + Math.round(dx));
                        lp.y = Math.max(0, startY + Math.round(dy));
                        try {
                            wm.updateViewLayout(bubble, lp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                    .putInt("x", lp.x).putInt("y", lp.y).apply();
                        } else {
                            openApp();
                        }
                        return true;
                }
                return false;
            }
        });
        refreshBubble();
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private void refreshBubble() {
        if (bubble == null) return;
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String rank = sp.getString("rank", "Gold");
        String hex = sp.getString("hex", "#f3c242");
        int stars = sp.getInt("stars", 0);
        int max = sp.getInt("max", 20);
        int color;
        try {
            color = Color.parseColor(hex);
        } catch (Exception e) {
            color = 0xFFF3C242;
        }
        String starText = "\u2605 " + stars + (max > 0 ? "/" + max : "");
        bubble.setState(rank, color, starText);
    }

    private void applyVisibility() {
        boolean show = !appInForeground && canOverlay(this);
        try {
            if (show && !attached) {
                wm.addView(bubble, lp);
                attached = true;
            } else if (!show && attached) {
                wm.removeView(bubble);
                attached = false;
            }
        } catch (Exception ignored) {
        }
    }

    private void removeBubble() {
        try {
            if (attached && bubble != null) wm.removeView(bubble);
        } catch (Exception ignored) {
        }
        attached = false;
    }

    // ---------------------------------------------------------------- view

    /** Round badge: rank name in rank color + star count. Nothing else. */
    static class BubbleView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rankP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint starP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private String rank = "Gold";
        private String starText = "\u2605 0";
        private int color = 0xFFF3C242;

        BubbleView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            fill.setColor(0xF0060A14);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(3f * d);
            rankP.setTypeface(Typeface.DEFAULT_BOLD);
            rankP.setTextAlign(Paint.Align.CENTER);
            starP.setTypeface(Typeface.DEFAULT_BOLD);
            starP.setTextAlign(Paint.Align.CENTER);
            starP.setColor(Color.WHITE);
            setLayerType(LAYER_TYPE_SOFTWARE, null); // needed for the glow ring
        }

        void setState(String rank, int color, String starText) {
            this.rank = rank;
            this.color = color;
            this.starText = starText;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - 2f * d;

            ring.setColor(color);
            ring.setShadowLayer(6f * d, 0, 0, color);
            cv.drawCircle(w / 2f, h / 2f, r, fill);
            cv.drawCircle(w / 2f, h / 2f, r, ring);

            // lines: rank words (max 2 lines) + stars
            String[] words = rank.split(" ");
            String l1 = words[0];
            String l2 = null;
            if (words.length > 1) {
                StringBuilder sb = new StringBuilder();
                for (int i = 1; i < words.length; i++) sb.append(i > 1 ? " " : "").append(words[i]);
                l2 = sb.toString();
            }
            String[] lines = l2 == null ? new String[]{l1, starText} : new String[]{l1, l2, starText};

            float maxW = w * 0.70f;
            float size = 13f * d;
            rankP.setTextSize(size);
            starP.setTextSize(size);
            for (String ln : lines) {
                float mw = rankP.measureText(ln);
                if (mw > maxW) size = Math.min(size, size * maxW / mw);
            }
            rankP.setTextSize(size);
            starP.setTextSize(size);
            rankP.setColor(color);

            float lh = size * 1.18f;
            float total = lh * lines.length;
            float y = h / 2f - total / 2f + lh * 0.82f;
            for (int i = 0; i < lines.length; i++) {
                Paint p = (i == lines.length - 1) ? starP : rankP;
                cv.drawText(lines[i], w / 2f, y, p);
                y += lh;
            }
        }
    }
}
