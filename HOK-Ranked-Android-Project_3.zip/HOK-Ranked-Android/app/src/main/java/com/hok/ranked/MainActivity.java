package com.hok.ranked;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.ViewGroup;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 1001;
    private static final int REQ_NOTIF = 1002;
    private static final int REQ_CAPTURE = 1003;

    /** The running activity (used by the capture service to wake the page up). */
    static volatile MainActivity current;

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean notifAsked = false;
    private boolean overlayAsked = false;
    private boolean batteryAsked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = this;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#020306"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#020306"));
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage = saved ranks/players
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new JsBridge(getApplicationContext()), "HOKAndroid");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.confirm())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue,
                                      final JsPromptResult result) {
                final EditText input = new EditText(MainActivity.this);
                if (defaultValue != null) input.setText(defaultValue);
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(input)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm(input.getText().toString()))
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onStart() {
        super.onStart();
        web.onResume();
        // App is visible -> hide the floating circle
        OverlayService.setAppForeground(this, true);
        pokeWeb();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Android 13+: ask notification permission first (foreground service notification)
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            notifAsked = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }

        if (OverlayService.canOverlay(this)) {
            if (OverlayService.instance == null) OverlayService.start(this);
            askBatteryExemption();
        } else if (!overlayAsked) {
            overlayAsked = true;
            new AlertDialog.Builder(this)
                    .setTitle("Display over other apps")
                    .setMessage("Para lumabas yung rank & stars circle sa ibabaw ng ibang apps, "
                            + "i-allow ang \"Display over other apps\" para sa HOK Ranked.")
                    .setPositiveButton("Open Settings", (d, w) -> {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    })
                    .setNegativeButton("Later", null)
                    .show();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        web.onPause();
        // App went to background -> show the floating circle
        OverlayService.setAppForeground(this, false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                try {
                    CaptureService.start(getApplicationContext(), resultCode, data);
                    Toast.makeText(this, "Auto detect ON. Open Honor of Kings and play.",
                            Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Could not start auto detect: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Screen capture was not allowed.", Toast.LENGTH_LONG).show();
            }
            // let the page refresh its status text a moment later (service needs a second to start)
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    evalJs("window.__hokStatus&&window.__hokStatus()");
                }
            }, 1200);
            return;
        }
        if (requestCode == REQ_FILE) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        // Keep the app (and the floating circle) alive instead of closing
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        if (web != null) {
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }

    // ---------------------------------------------------------------- auto detect helpers

    /** Asks Android for the screen-capture permission (system dialog). Choose "Entire screen". */
    void requestCapture() {
        try {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            Toast.makeText(this, "Choose \"Entire screen\" > Start now", Toast.LENGTH_LONG).show();
            startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
        } catch (Exception e) {
            Toast.makeText(this, "Screen capture not available: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void evalJs(final String js) {
        if (web == null) return;
        try {
            web.evaluateJavascript(js, null);
        } catch (Exception ignored) {
        }
    }

    /** Tells the page that a detected match is waiting (called by CaptureService). */
    static void pokeWeb() {
        final MainActivity a = current;
        if (a == null) return;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                a.evalJs("window.__hokPoll&&window.__hokPoll()");
            }
        });
    }

    static boolean batteryOk(Context c) {
        if (Build.VERSION.SDK_INT < 23) return true;
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm == null || pm.isIgnoringBatteryOptimizations(c.getPackageName());
    }

    static void openBatterySettings(Context c) {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + c.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            try {
                Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            } catch (Exception ignored) {
            }
        }
    }

    /** One-time prompt so the phone does not kill the bubble / auto detect in the background. */
    private void askBatteryExemption() {
        if (batteryAsked || batteryOk(this)) return;
        SharedPreferences sp = getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE);
        if (sp.getBoolean("battery_asked", false)) return;
        batteryAsked = true;
        sp.edit().putBoolean("battery_asked", true).apply();
        new AlertDialog.Builder(this)
                .setTitle("Keep the circle running")
                .setMessage("Para hindi patayin ng phone yung circle at auto-detect habang naglalaro ka, "
                        + "i-allow ang \"Don't optimize / Unrestricted battery\" para sa HOK Ranked.")
                .setPositiveButton("Allow", (d, w) -> openBatterySettings(MainActivity.this))
                .setNegativeButton("Later", null)
                .show();
    }

    /** Finds the real Honor of Kings app: known package names first, then by app name. */
    static Intent findHok(Context c) {
        PackageManager pm = c.getPackageManager();
        String[] known = {
                "com.levelinfinite.sgameGlobal",
                "com.levelinfinite.sgameGlobal.midaspay",
                "com.tencent.tmgp.sgame"
        };
        for (String pkg : known) {
            Intent i = pm.getLaunchIntentForPackage(pkg);
            if (i != null) return i;
        }
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            String label = String.valueOf(ri.loadLabel(pm)).toLowerCase();
            if (label.contains("honor of kings") || label.contains("\u738b\u8005\u8363\u8000")) {
                Intent i = pm.getLaunchIntentForPackage(ri.activityInfo.packageName);
                if (i != null) return i;
            }
        }
        return null;
    }

    /** Receives rank + stars from the page (see the script appended to index.html). */
    static class JsBridge {
        private final Context ctx;

        JsBridge(Context c) {
            ctx = c;
        }

        @android.webkit.JavascriptInterface
        public void update(String player, String rank, String hex, String symbol, int stars, int maxStars) {
            OverlayService.updateState(ctx, player, rank, hex, stars, maxStars);
        }

        @android.webkit.JavascriptInterface
        public void launchHok() {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    Intent i = findHok(ctx);
                    if (i != null) {
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        try {
                            ctx.startActivity(i);
                            return;
                        } catch (Exception ignored) {
                        }
                    }
                    Toast.makeText(ctx, "Honor of Kings not found on this phone", Toast.LENGTH_LONG).show();
                }
            });
        }

        @android.webkit.JavascriptInterface
        public int getBubbleSize() {
            return OverlayService.getSizeDp(ctx);
        }

        @android.webkit.JavascriptInterface
        public void setBubbleSize(int dp) {
            OverlayService.setSizeDp(ctx, dp);
        }

        // ---- auto detect (real game) ----

        @android.webkit.JavascriptInterface
        public void startAutoDetect() {
            final MainActivity a = current;
            if (a != null) a.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    a.requestCapture();
                }
            });
        }

        @android.webkit.JavascriptInterface
        public void stopAutoDetect() {
            CaptureService.stop(ctx);
        }

        @android.webkit.JavascriptInterface
        public boolean isAutoDetectOn() {
            return CaptureService.running;
        }

        /** JSON array of detected matches not yet applied, or "" (clears the queue). */
        @android.webkit.JavascriptInterface
        public String popResults() {
            return ResultQueue.popJson(ctx);
        }

        @android.webkit.JavascriptInterface
        public String getDebug() {
            return CaptureService.debug;
        }

        @android.webkit.JavascriptInterface
        public String getMyName() {
            return CaptureService.getName(ctx);
        }

        @android.webkit.JavascriptInterface
        public void setMyName(String name) {
            CaptureService.setName(ctx, name);
        }

        @android.webkit.JavascriptInterface
        public boolean getAutoRecord() {
            return CaptureService.getAutoRecord(ctx);
        }

        @android.webkit.JavascriptInterface
        public void setAutoRecord(boolean on) {
            CaptureService.setAutoRecord(ctx, on);
        }

        @android.webkit.JavascriptInterface
        public boolean isBatteryOk() {
            return batteryOk(ctx);
        }

        @android.webkit.JavascriptInterface
        public void openBatterySettings() {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    MainActivity.openBatterySettings(ctx);
                }
            });
        }
    }
}
