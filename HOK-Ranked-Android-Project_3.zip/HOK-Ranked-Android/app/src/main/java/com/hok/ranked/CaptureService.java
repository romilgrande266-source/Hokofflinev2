package com.hok.ranked;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Executor;

/**
 * Auto-detect for the real game.
 *
 * The user allows screen capture once (system dialog). This foreground service then looks at
 * the screen every ~2 seconds, runs on-device OCR (ML Kit, offline) and:
 *   1. waits for a big VICTORY / DEFEAT banner (seen twice, to avoid false alarms),
 *   2. keeps reading for a few seconds to find the player's own row (MVP tag + K/D/A),
 *   3. computes the grade (C..SSS) and queues the result for the rank system (ResultQueue),
 *   4. flashes the result in the floating bubble.
 *
 * Nothing leaves the phone and no picture is stored. It is paused while this app is on screen
 * (the app itself has VICTORY / DEFEAT buttons that would be read by mistake).
 */
public class CaptureService extends Service {

    static final String CHANNEL_ID = "hok_capture";
    static final int NOTIF_ID = 2;
    static final String ACTION_START = "com.hok.ranked.CAPTURE_START";
    static final String ACTION_STOP = "com.hok.ranked.CAPTURE_STOP";
    static final String EXTRA_CODE = "code";
    static final String EXTRA_DATA = "data";

    static final String PREFS = "hok_capture_prefs";

    static volatile boolean running = false;
    static volatile String debug = "";

    // timing / sizes
    private static final long IDLE_MS = 2000;       // looking for the banner
    private static final long COLLECT_MS = 1200;    // banner found, reading the table
    private static final long COLLECT_MAX_MS = 22000;
    private static final long NO_NAME_COLLECT_MS = 3500;
    private static final long REARM_MIN_MS = 30000;
    private static final int IDLE_WIDTH = 960;      // OCR width while idle
    private static final int MAX_CAPTURE_DIM = 1280;

    private static final int ST_IDLE = 0, ST_COLLECT = 1;

    private HandlerThread thread;
    private Handler bg;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Executor bgExec = new Executor() {
        @Override
        public void execute(Runnable r) {
            if (bg != null) bg.post(r);
        }
    };

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private int curW, curH;
    private Bitmap lastFrame;
    private boolean busy = false;
    private boolean stopping = false;

    // state machine
    private int state = ST_IDLE;
    private boolean armed = true;
    private int noBannerStreak = 0;
    private long lastRecordedAt = 0;
    private int sightOutcome = MatchDetector.NONE;
    private int sightings = 0;
    private long lastSightingAt = 0;
    private long collectStart = 0;
    private int cMvpHits, cKdaHits, cK = -1, cD = -1, cA = -1;

    // ---------------------------------------------------------------- static API

    static void start(Context c, int resultCode, Intent data) {
        Intent i = new Intent(c, CaptureService.class)
                .setAction(ACTION_START)
                .putExtra(EXTRA_CODE, resultCode)
                .putExtra(EXTRA_DATA, data);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    static void stop(Context c) {
        try {
            c.startService(new Intent(c, CaptureService.class).setAction(ACTION_STOP));
        } catch (Exception ignored) {
        }
    }

    static String getName(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getString("name", "");
    }

    static void setName(Context c, String name) {
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("name", name == null ? "" : name.trim()).apply();
    }

    static boolean getAutoRecord(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("auto_record", true);
    }

    static void setAutoRecord(Context c, boolean on) {
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("auto_record", on).apply();
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            shutdown();
            return START_NOT_STICKY;
        }

        // Must be promoted to foreground right away (type mediaProjection)
        createChannel();
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            debug = "startForeground failed: " + e;
            shutdown();
            return START_NOT_STICKY;
        }

        if (intent == null || !ACTION_START.equals(intent.getAction()) || running) {
            // restarted by the system without a fresh permission -> cannot capture
            if (!running) shutdown();
            return START_NOT_STICKY;
        }

        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        if (data == null) {
            shutdown();
            return START_NOT_STICKY;
        }

        try {
            thread = new HandlerThread("hok-detect");
            thread.start();
            bg = new Handler(thread.getLooper());

            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            if (projection == null) throw new IllegalStateException("no projection");
            // Android 14+: callback must be registered before createVirtualDisplay
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            shutdown();
                        }
                    });
                }
            }, bg);

            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            DisplayMetrics dm = realMetrics();
            int[] sz = captureSize(dm.widthPixels, dm.heightPixels);
            reader = ImageReader.newInstance(sz[0], sz[1], PixelFormat.RGBA_8888, 2);
            vd = projection.createVirtualDisplay("hok-detect", sz[0], sz[1], dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, bg);
            curW = sz[0];
            curH = sz[1];
        } catch (Throwable t) {
            debug = "capture start failed: " + t;
            shutdown();
            return START_NOT_STICKY;
        }

        running = true;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", true).apply();
        debug = "running";
        OverlayService.refresh();
        bg.postDelayed(tick, 1500);
        return START_NOT_STICKY;
    }

    private void shutdown() {
        if (stopping) return;
        stopping = true;
        running = false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("on", false).apply();
        try {
            if (bg != null) bg.removeCallbacksAndMessages(null);
        } catch (Exception ignored) {
        }
        try {
            if (vd != null) vd.release();
        } catch (Exception ignored) {
        }
        try {
            if (reader != null) reader.close();
        } catch (Exception ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Exception ignored) {
        }
        try {
            if (recognizer != null) recognizer.close();
        } catch (Exception ignored) {
        }
        try {
            if (thread != null) thread.quitSafely();
        } catch (Exception ignored) {
        }
        if (lastFrame != null) {
            try {
                lastFrame.recycle();
            } catch (Exception ignored) {
            }
            lastFrame = null;
        }
        OverlayService.refresh();
        stopForeground(true);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---------------------------------------------------------------- notification

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Auto-detect", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | imm);
        Intent stop = new Intent(this, CaptureService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 11, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | imm);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_star)
                .setContentTitle("HOK Ranked - auto detect ON")
                .setContentText("Reading the match result on this phone only.")
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(0, "Stop auto detect", stopPi);
        return b.build();
    }

    // ---------------------------------------------------------------- scanning loop

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long next = IDLE_MS;
            try {
                next = doTick();
            } catch (Throwable t) {
                debug = "tick error: " + t;
                busy = false;
            }
            if (running && bg != null) bg.postDelayed(this, next);
        }
    };

    private long doTick() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) return IDLE_MS * 2;   // screen off
        if (OverlayService.appInForeground) return IDLE_MS;          // our own app is showing
        if (busy) return 500;

        ensureSize();
        grabFrame();
        if (lastFrame == null) return 500;

        boolean collecting = state == ST_COLLECT;
        int tw = collecting ? lastFrame.getWidth() : Math.min(IDLE_WIDTH, lastFrame.getWidth());
        int th = Math.max(2, Math.round(lastFrame.getHeight() * (tw / (float) lastFrame.getWidth())));
        final Bitmap bmp = scaled(lastFrame, tw, th);
        final int fw = bmp.getWidth(), fh = bmp.getHeight();

        busy = true;
        recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener(bgExec, new com.google.android.gms.tasks.OnSuccessListener<Text>() {
                    @Override
                    public void onSuccess(Text text) {
                        busy = false;
                        try {
                            bmp.recycle();
                        } catch (Exception ignored) {
                        }
                        try {
                            onText(text, fw, fh);
                        } catch (Throwable t) {
                            debug = "scan error: " + t;
                        }
                    }
                })
                .addOnFailureListener(bgExec, new com.google.android.gms.tasks.OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        busy = false;
                        try {
                            bmp.recycle();
                        } catch (Exception ignored) {
                        }
                        debug = "ocr failed: " + e;
                    }
                });
        return collecting ? COLLECT_MS : IDLE_MS;
    }

    // ---------------------------------------------------------------- state machine

    private void onText(Text text, int fw, int fh) {
        long now = System.currentTimeMillis();
        List<MatchDetector.Line> lines = new ArrayList<>();
        for (Text.TextBlock b : text.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                Rect r = l.getBoundingBox();
                if (r == null) continue;
                lines.add(new MatchDetector.Line(l.getText(), r.left, r.top, r.right, r.bottom));
            }
        }
        String name = getName(this);
        MatchDetector.Scan s = MatchDetector.scan(lines, fw, fh, name);
        updateDebug(lines, s, fh);

        if (state == ST_IDLE) {
            if (!armed) {
                // wait until the result screen is gone before accepting another match
                if (s.outcome == MatchDetector.NONE) {
                    noBannerStreak++;
                    if (noBannerStreak >= 3 && now - lastRecordedAt > REARM_MIN_MS) armed = true;
                } else {
                    noBannerStreak = 0;
                }
                return;
            }
            if (s.outcome == MatchDetector.NONE) {
                if (now - lastSightingAt > 6000) sightings = 0;
                return;
            }
            if (s.outcome != sightOutcome) {
                sightOutcome = s.outcome;
                sightings = 0;
            }
            if (sightings == 0 || now - lastSightingAt >= 600) {
                sightings++;
                lastSightingAt = now;
            }
            if (sightings >= 2) {
                state = ST_COLLECT;
                collectStart = now;
                cMvpHits = 0;
                cKdaHits = 0;
                cK = cD = cA = -1;
                OverlayService.flash("...", "reading", "result", 0xFFFFFFFF, 3000);
            }
            return;
        }

        // ST_COLLECT: gather MVP tag + KDA of my row
        if (s.mvp) cMvpHits++;
        if (s.hasKda()) {
            cKdaHits++;
            cK = s.k;
            cD = s.d;
            cA = s.a;
        }
        long el = now - collectStart;
        boolean haveName = MatchDetector.norm(name).length() >= 2;
        boolean complete = haveName ? cKdaHits >= 2 : el >= NO_NAME_COLLECT_MS;
        if (complete || el >= COLLECT_MAX_MS) finishMatch(now);
    }

    private void finishMatch(long now) {
        boolean win = sightOutcome == MatchDetector.WIN;
        boolean mvp = cMvpHits >= 1;
        String grade = MatchDetector.grade(sightOutcome, mvp, cK, cD, cA);
        final ResultQueue.Result r = new ResultQueue.Result(now, win, mvp, grade, cK, cD, cA);
        ResultQueue.push(this, r);

        state = ST_IDLE;
        armed = false;
        noBannerStreak = 0;
        sightings = 0;
        lastRecordedAt = now;
        debug = "RESULT: " + (win ? "WIN" : "LOSE") + " mvp=" + mvp + " grade=" + grade
                + " kda=" + cK + "/" + cD + "/" + cA + "\n" + debug;

        // let the page apply it right now if it is alive
        MainActivity.pokeWeb();
        final boolean w = win, m = mvp;
        final String g = grade;
        final boolean auto = getAutoRecord(this);
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                boolean done = ResultQueue.size(CaptureService.this) == 0;
                String status = done ? (auto ? "SAVED" : "READY") : "OPEN APP";
                OverlayService.flash(w ? "WIN" : "LOSE", (m ? "MVP " : "") + g, status,
                        w ? 0xFF00FF87 : 0xFFFF4D6D, 6000);
            }
        }, 2500);
        OverlayService.flash(win ? "WIN" : "LOSE", (mvp ? "MVP " : "") + grade, "...",
                win ? 0xFF00FF87 : 0xFFFF4D6D, 3000);
    }

    private void updateDebug(List<MatchDetector.Line> lines, MatchDetector.Scan s, int fh) {
        try {
            List<MatchDetector.Line> sorted = new ArrayList<>(lines);
            Collections.sort(sorted, new Comparator<MatchDetector.Line>() {
                @Override
                public int compare(MatchDetector.Line a, MatchDetector.Line b) {
                    return b.h() - a.h();
                }
            });
            StringBuilder sb = new StringBuilder();
            sb.append(state == ST_COLLECT ? "COLLECT" : (armed ? "WATCHING" : "COOLDOWN"));
            sb.append(" | banner=").append(s.outcome == MatchDetector.WIN ? "WIN"
                    : s.outcome == MatchDetector.LOSE ? "LOSE" : "-");
            sb.append(" name=").append(s.nameFound ? "yes" : "no");
            sb.append(" mvp=").append(s.mvp ? "yes" : "no");
            sb.append(" kda=").append(s.hasKda() ? s.k + "/" + s.d + "/" + s.a : "-");
            sb.append(" | lines=").append(lines.size()).append("\n");
            int n = Math.min(10, sorted.size());
            for (int i = 0; i < n; i++) {
                MatchDetector.Line l = sorted.get(i);
                String t = l.text.replace('\n', ' ');
                if (t.length() > 24) t = t.substring(0, 24);
                sb.append(t).append(" (").append(Math.round(100f * l.h() / fh)).append("%)\n");
            }
            debug = sb.toString();
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- frame grabbing

    private DisplayMetrics realMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }

    private static int[] captureSize(int w, int h) {
        float scale = Math.min(1f, MAX_CAPTURE_DIM / (float) Math.max(w, h));
        int cw = Math.max(2, (int) (w * scale) & ~1);
        int ch = Math.max(2, (int) (h * scale) & ~1);
        return new int[]{cw, ch};
    }

    /** The game is landscape: when the phone rotates, rebuild the capture surface to match. */
    private void ensureSize() {
        try {
            DisplayMetrics dm = realMetrics();
            int[] sz = captureSize(dm.widthPixels, dm.heightPixels);
            if (sz[0] == curW && sz[1] == curH) return;
            ImageReader nr = ImageReader.newInstance(sz[0], sz[1], PixelFormat.RGBA_8888, 2);
            vd.resize(sz[0], sz[1], dm.densityDpi);
            vd.setSurface(nr.getSurface());
            ImageReader old = reader;
            reader = nr;
            curW = sz[0];
            curH = sz[1];
            if (old != null) old.close();
            if (lastFrame != null) {
                lastFrame.recycle();
                lastFrame = null;
            }
        } catch (Throwable t) {
            debug = "resize failed: " + t;
        }
    }

    /** Keeps the newest frame in lastFrame. A still screen produces no new frame, so the old one stays valid. */
    private void grabFrame() {
        Image img = null;
        try {
            img = reader.acquireLatestImage();
            if (img == null) return;
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            int ps = p.getPixelStride(), rs = p.getRowStride();
            int w = img.getWidth(), h = img.getHeight();
            int pad = rs - ps * w;
            Bitmap bmp = Bitmap.createBitmap(w + pad / ps, h, Bitmap.Config.ARGB_8888);
            bmp.copyPixelsFromBuffer(buf);
            if (pad != 0) {
                Bitmap c = Bitmap.createBitmap(bmp, 0, 0, w, h);
                bmp.recycle();
                bmp = c;
            }
            if (lastFrame != null) lastFrame.recycle();
            lastFrame = bmp;
        } catch (Throwable t) {
            debug = "grab failed: " + t;
        } finally {
            if (img != null) img.close();
        }
    }

    private static Bitmap scaled(Bitmap src, int w, int h) {
        if (src.getWidth() == w && src.getHeight() == h) {
            Bitmap c = src.copy(Bitmap.Config.ARGB_8888, false);
            if (c == null) throw new IllegalStateException("bitmap copy failed");
            return c;
        }
        return Bitmap.createScaledBitmap(src, w, h, true);
    }
}
