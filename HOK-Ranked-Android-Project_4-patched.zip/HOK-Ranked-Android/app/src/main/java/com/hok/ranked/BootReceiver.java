package com.hok.ranked;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Brings the rank bubble back after a reboot or after the app is updated. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            if (OverlayService.canOverlay(context)) {
                OverlayService.start(context);
            }
        }
    }
}
