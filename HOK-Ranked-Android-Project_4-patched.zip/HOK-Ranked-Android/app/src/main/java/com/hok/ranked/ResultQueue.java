package com.hok.ranked;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Detected matches waiting to be applied by the web page (rank system).
 * Stored in SharedPreferences so nothing is lost if the page / activity is not alive
 * when the match ends; the page picks them up the next time it runs.
 */
final class ResultQueue {

    private static final String PREFS = "hok_results";
    private static final String KEY = "pending";
    private static final int MAX = 20;
    private static final Object LOCK = new Object();

    private ResultQueue() {
    }

    static final class Result {
        final long time;
        final boolean win, mvp;
        final String grade;
        final int k, d, a;

        Result(long time, boolean win, boolean mvp, String grade, int k, int d, int a) {
            this.time = time;
            this.win = win;
            this.mvp = mvp;
            this.grade = grade;
            this.k = k;
            this.d = d;
            this.a = a;
        }

        String encode() {
            return time + "," + (win ? 1 : 0) + "," + (mvp ? 1 : 0) + "," + grade + "," + k + "," + d + "," + a;
        }

        String json() {
            return "{\"t\":" + time + ",\"win\":" + win + ",\"mvp\":" + mvp + ",\"grade\":\"" + grade
                    + "\",\"k\":" + k + ",\"d\":" + d + ",\"a\":" + a + "}";
        }
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static void push(Context c, Result r) {
        synchronized (LOCK) {
            String cur = sp(c).getString(KEY, "");
            String[] parts = cur.isEmpty() ? new String[0] : cur.split(";");
            StringBuilder sb = new StringBuilder();
            int start = Math.max(0, parts.length - (MAX - 1));
            for (int i = start; i < parts.length; i++) sb.append(parts[i]).append(';');
            sb.append(r.encode());
            sp(c).edit().putString(KEY, sb.toString()).apply();
        }
    }

    static int size(Context c) {
        synchronized (LOCK) {
            String cur = sp(c).getString(KEY, "");
            return cur.isEmpty() ? 0 : cur.split(";").length;
        }
    }

    /** Returns a JSON array ("[{...},{...}]") of everything pending and clears the queue, or "" if empty. */
    static String popJson(Context c) {
        synchronized (LOCK) {
            String cur = sp(c).getString(KEY, "");
            if (cur.isEmpty()) return "";
            sp(c).edit().remove(KEY).apply();
            StringBuilder sb = new StringBuilder("[");
            boolean first = true;
            for (String p : cur.split(";")) {
                Result r = decode(p);
                if (r == null) continue;
                if (!first) sb.append(',');
                sb.append(r.json());
                first = false;
            }
            sb.append(']');
            return first ? "" : sb.toString();
        }
    }

    private static Result decode(String s) {
        try {
            String[] f = s.split(",");
            if (f.length < 7) return null;
            String g = f[3];
            if (!g.matches("C|B|A|A\\+|S|SS|SSS")) return null;
            return new Result(Long.parseLong(f[0]), f[1].equals("1"), f[2].equals("1"), g,
                    Integer.parseInt(f[4]), Integer.parseInt(f[5]), Integer.parseInt(f[6]));
        } catch (Exception e) {
            return null;
        }
    }
}
