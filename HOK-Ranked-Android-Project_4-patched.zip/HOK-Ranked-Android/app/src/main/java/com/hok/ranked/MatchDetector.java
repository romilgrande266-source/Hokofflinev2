package com.hok.ranked;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pure-Java parsing of OCR output from the Honor of Kings screen (no Android classes,
 * so it can be unit-tested on a PC).
 *
 * What it looks for:
 *  - a big "VICTORY" / "DEFEAT" banner                       -> outcome
 *  - the player's own row on the result table (found by the in-game name typed in the app)
 *      * "MVP" tag in that row                               -> mvp
 *      * "K/D/A" numbers in that row                         -> grade C..SSS
 */
final class MatchDetector {

    static final int NONE = 0, WIN = 1, LOSE = 2;

    // KDA grade thresholds on (K + 0.7*A) / max(1, D). Edit here to tune the grading.
    static final double T_B = 1.0, T_A = 2.0, T_AP = 3.0, T_S = 4.0, T_SS = 5.5, T_SSS = 8.0;

    private static final Pattern KDA = Pattern.compile(
            "(?<!\\d)(\\d{1,2})\\s*[/|\\\\]\\s*(\\d{1,2})\\s*[/|\\\\]\\s*(\\d{1,2})(?!\\d)");

    static final class Line {
        final String text;
        final int l, t, r, b;

        Line(String text, int l, int t, int r, int b) {
            this.text = text == null ? "" : text;
            this.l = l;
            this.t = t;
            this.r = r;
            this.b = b;
        }

        int cx() {
            return (l + r) / 2;
        }

        int cy() {
            return (t + b) / 2;
        }

        int h() {
            return b - t;
        }
    }

    static final class Scan {
        int outcome = NONE;
        boolean nameFound;
        String name = "";        // name read from the highlighted row (auto mode)
        boolean mvp;
        int k = -1, d = -1, a = -1;

        boolean hasKda() {
            return k >= 0;
        }
    }

    // ------------------------------------------------------------------ main entry

    static Scan scan(List<Line> lines, int w, int h, String myName) {
        Scan s = new Scan();
        s.outcome = findOutcome(lines, h);

        String nm = norm(myName);
        if (nm.length() < 2) return s;

        List<Line> hits = new ArrayList<>();
        for (Line ln : lines) {
            if (nameMatches(norm(ln.text), nm)) hits.add(ln);
        }
        if (hits.isEmpty()) return s;

        Scan best = null;
        for (Line nl : hits) {
            Scan c = new Scan();
            c.outcome = s.outcome;
            c.nameFound = true;
            int half = Math.max((int) (nl.h() * 1.2f), (int) (h * 0.04f));
            int bestKdaDist = Integer.MAX_VALUE;
            for (Line o : lines) {
                if (Math.abs(o.cy() - nl.cy()) > half) continue;
                int dist = Math.abs(o.cx() - nl.cx());

                Matcher m = KDA.matcher(o.text);
                if (m.find() && dist < bestKdaDist) {
                    int k = Integer.parseInt(m.group(1));
                    int d = Integer.parseInt(m.group(2));
                    int a = Integer.parseInt(m.group(3));
                    if (k <= 60 && d <= 60 && a <= 90) {
                        bestKdaDist = dist;
                        c.k = k;
                        c.d = d;
                        c.a = a;
                    }
                }
                if (hasMvpToken(o.text) && dist <= w * 0.30f) c.mvp = true;
            }
            if (best == null || (c.hasKda() && !best.hasKda())) best = c;
        }
        return best;
    }


    // ------------------------------------------------------------------ auto: find MY row by its highlight

    /** Gives the screen colour (0xRRGGBB) at a position of the scanned frame. */
    interface Probe {
        int rgb(int x, int y);
    }

    private static final double HL_MIN_RATIO = 1.25;   // my row must be this much brighter than the median row
    private static final double HL_MIN_DIFF = 18;      // ...and at least this much brighter (0..255 luma)
    private static final double HL_MIN_GAP = 10;       // ...and clearly ahead of the 2nd brightest row

    private static double luma(int rgb) {
        return 0.299 * ((rgb >> 16) & 255) + 0.587 * ((rgb >> 8) & 255) + 0.114 * (rgb & 255);
    }

    private static double median(double[] v) {
        double[] c = v.clone();
        java.util.Arrays.sort(c);
        return c[c.length / 2];
    }

    /** Background brightness of a result-table row, sampled just left of its K/D/A text. */
    private static double rowLuma(Line kda, int w, int h, Probe probe) {
        double[] samples = new double[9];
        int n = 0;
        int[] dx = {Math.round(w * 0.012f), Math.round(w * 0.020f), Math.round(w * 0.030f)};
        int[] dy = {-Math.round(kda.h() * 0.3f), 0, Math.round(kda.h() * 0.3f)};
        for (int a : dx) {
            for (int b : dy) {
                int x = Math.max(0, Math.min(w - 1, kda.l - a));
                int y = Math.max(0, Math.min(h - 1, kda.cy() + b));
                samples[n++] = luma(probe.rgb(x, y));
            }
        }
        return median(samples);   // median ignores the odd pixel that lands on a glyph
    }

    /**
     * Same as {@link #scan} but needs no typed name: the player's own row is the one whose
     * background is brighter than the other rows of its team. Name, MVP and K/D/A are read from it.
     */
    static Scan scanAuto(List<Line> lines, int w, int h, Probe probe) {
        Scan s = new Scan();
        s.outcome = findOutcome(lines, h);

        List<Line> rows = new ArrayList<>();
        for (Line ln : lines) {
            if (parseKda(ln.text) != null) rows.add(ln);
        }
        if (rows.size() < 4) return s;

        // team columns: left half / right half of the screen
        Line best = null;
        double bestDiff = 0;
        for (int side = 0; side < 2; side++) {
            List<Line> col = new ArrayList<>();
            for (Line r : rows) {
                if ((r.cx() < w / 2) == (side == 0)) col.add(r);
            }
            if (col.size() < 3) continue;
            double[] lum = new double[col.size()];
            for (int i = 0; i < col.size(); i++) lum[i] = rowLuma(col.get(i), w, h, probe);
            double med = median(lum);
            int top = 0;
            for (int i = 1; i < lum.length; i++) if (lum[i] > lum[top]) top = i;
            double second = -1;
            for (int i = 0; i < lum.length; i++) if (i != top && lum[i] > second) second = lum[i];
            double diff = lum[top] - med;
            if (lum[top] >= med * HL_MIN_RATIO && diff >= HL_MIN_DIFF
                    && lum[top] - second >= HL_MIN_GAP && diff > bestDiff) {
                bestDiff = diff;
                best = col.get(top);
            }
        }
        if (best == null) return s;

        // name = nearest readable text to the LEFT of the K/D/A on the same row
        int half = Math.max((int) (best.h() * 1.2f), (int) (h * 0.04f));
        Line nameLine = null;
        for (Line o : lines) {
            if (o == best) continue;
            if (Math.abs(o.cy() - best.cy()) > half) continue;
            if (o.r > best.l) continue;                       // must end before the K/D/A
            if (hasMvpToken(o.text)) continue;
            String n = norm(o.text);
            if (n.length() < 2) continue;
            boolean allDigits = true;
            for (char c : n.toCharArray()) if (!Character.isDigit(c)) allDigits = false;
            if (allDigits) continue;
            if (nameLine == null || o.r > nameLine.r) nameLine = o;
        }

        int[] k = parseKda(best.text);
        s.k = k[0];
        s.d = k[1];
        s.a = k[2];
        for (Line o : lines) {
            if (Math.abs(o.cy() - best.cy()) > half) continue;
            if (hasMvpToken(o.text) && Math.abs(o.cx() - best.cx()) <= w * 0.30f) s.mvp = true;
        }
        if (nameLine != null) {
            s.nameFound = true;
            s.name = nameLine.text.trim();
        }
        return s;
    }

    private static int[] parseKda(String text) {
        Matcher m = KDA.matcher(text);
        if (!m.find()) return null;
        int k = Integer.parseInt(m.group(1));
        int d = Integer.parseInt(m.group(2));
        int a = Integer.parseInt(m.group(3));
        if (k > 60 || d > 60 || a > 90) return null;
        return new int[]{k, d, a};
    }

    // ------------------------------------------------------------------ outcome

    private static int findOutcome(List<Line> lines, int h) {
        int win = 0, lose = 0;
        for (Line ln : lines) {
            String txt = ln.text.trim();
            if (txt.length() > 14) continue;            // banner is a single short word
            if (ln.h() < h * 0.035f) continue;          // ...and it is BIG
            for (String tok : txt.toUpperCase(Locale.ROOT).split("[^A-Z0-9]+")) {
                // Filipino game language: "TALO" (4 letters, so exact match only)
                if (tok.equals("TALO") || tok.equals("NATALO")) { lose++; continue; }
                if (tok.equals("PANALO") || tok.equals("NANALO") || tok.equals("TAGUMPAY")) { win++; continue; }
                if (tok.length() < 6) continue;
                if (close(tok, "VICTORY")) win++;
                else if (close(tok, "DEFEAT")) lose++;
            }
        }
        if (win > 0 && lose == 0) return WIN;
        if (lose > 0 && win == 0) return LOSE;
        return NONE;
    }

    private static boolean hasMvpToken(String text) {
        for (String tok : text.toUpperCase(Locale.ROOT).split("[^A-Z0-9]+")) {
            if (tok.equals("MVP")) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ grade

    /** C, B, A, A+, S, SS or SSS. */
    static String grade(int outcome, boolean mvp, int k, int d, int a) {
        if (k < 0) {
            // KDA could not be read: use a neutral default
            if (outcome == WIN) return mvp ? "S" : "A";
            return mvp ? "A" : "B";
        }
        double r = (k + a * 0.7) / Math.max(1, d);
        if (r >= T_SSS) return "SSS";
        if (r >= T_SS) return "SS";
        if (r >= T_S) return "S";
        if (r >= T_AP) return "A+";
        if (r >= T_A) return "A";
        if (r >= T_B) return "B";
        return "C";
    }

    // ------------------------------------------------------------------ text helpers

    static String norm(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (Character.isLetterOrDigit(c)) sb.append(c);
        }
        return sb.toString();
    }

    private static boolean nameMatches(String line, String name) {
        if (line.isEmpty() || name.isEmpty()) return false;
        if (name.length() >= 3 && line.contains(name)) return true;
        if (line.equals(name)) return true;
        if (name.length() >= 4 && similarity(line, name) >= 0.8) return true;
        // name shown truncated ("Shadowkil...") in the table
        return line.length() >= 4 && name.length() > line.length()
                && name.startsWith(line) && line.length() >= name.length() * 0.6;
    }

    private static boolean close(String tok, String word) {
        if (Math.abs(tok.length() - word.length()) > 1) return false;
        if (tok.charAt(0) != word.charAt(0)) return false;
        int allowed = word.length() >= 7 ? 2 : 1;   // OCR may swap look-alikes (I/l, O/0)
        return lev(tok, word) <= allowed;
    }

    private static double similarity(String a, String b) {
        int m = Math.max(a.length(), b.length());
        if (m == 0) return 1;
        return 1.0 - (double) lev(a, b) / m;
    }

    private static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }
}
