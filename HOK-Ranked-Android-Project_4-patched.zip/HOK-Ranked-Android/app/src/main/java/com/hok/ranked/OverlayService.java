package com.hok.ranked;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

/**
 * Foreground service that keeps running in the background and draws a small circle
 * (rank + stars) over other apps. Tap the circle -> back to the app. Drag to move.
 *
 * Keep-alive measures: foreground service + sticky restart, a watchdog that re-attaches the
 * bubble if the system removed it, restart when the app is swiped away, restart after
 * reboot / update (BootReceiver).
 */
public class OverlayService extends Service {

    static final String CHANNEL_ID = "hok_overlay";
    static final int NOTIF_ID = 1;
    static final String ACTION_STOP = "com.hok.ranked.STOP";
    static final String PREFS = "hok_overlay_prefs";
    private static final long WATCHDOG_MS = 4000;

    static volatile OverlayService instance;
    // false by default: if the process is restarted while the game is open, the bubble must show.
    // MainActivity sets this to true in onStart().
    static volatile boolean appInForeground = false;

    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private BubbleView bubble;
    private WindowManager.LayoutParams lp;
    private boolean attached = false;

    private final Runnable clearFlash = new Runnable() {
        @Override
        public void run() {
            if (bubble != null) bubble.setFlash(null, 0);
        }
    };

    /** Periodically makes sure the bubble is really on screen when it should be. */
    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            try {
                boolean show = !appInForeground && canOverlay(OverlayService.this);
                if (show && attached && bubble != null && !bubble.isAttachedToWindow()) {
                    // the system dropped our window: add it again
                    try {
                        wm.removeViewImmediate(bubble);
                    } catch (Exception ignored) {
                    }
                    attached = false;
                }
                applyVisibility();
            } catch (Exception ignored) {
            } finally {
                main.postDelayed(this, WATCHDOG_MS);
            }
        }
    };

    // ---------------------------------------------------------------- static helpers

    static boolean canOverlay(Context c) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    }

    private static boolean crashLogInstalled = false;

    /** Remembers the last crash so it can be shown in Settings > Auto detect > "Last scan". */
    static synchronized void installCrashLogger(Context c) {
        if (crashLogInstalled) return;
        crashLogInstalled = true;
        final Context app = c.getApplicationContext();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StackTraceElement[] st = e.getStackTrace();
                    StringBuilder sb = new StringBuilder();
                    sb.append(new java.util.Date()).append(" ").append(e);
                    for (int i = 0; i < Math.min(5, st.length); i++) sb.append("\n  at ").append(st[i]);
                    app.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putString("last_crash", sb.toString()).commit();
                } catch (Throwable ignored) {
                }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
    }

    static boolean isEnabled(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("enabled", true);
    }

    static void start(Context c) {
        try {
            c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("enabled", true).apply();
            Intent i = new Intent(c, OverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        } catch (Exception ignored) {
        }
    }

    static void setAppForeground(Context c, boolean fg) {
        appInForeground = fg;
        final OverlayService s = instance;
        if (s != null) {
            s.main.post(s::applyVisibility);
        } else if (!fg && canOverlay(c) && isEnabled(c)) {
            start(c);
        }
    }

    static final int SIZE_MIN = 56, SIZE_MAX = 140, SIZE_DEFAULT = 84;

    static int getSizeDp(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getInt("size", SIZE_DEFAULT);
    }

    static void setSizeDp(Context c, int dp) {
        dp = Math.max(SIZE_MIN, Math.min(SIZE_MAX, dp));
        c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("size", dp).apply();
        final OverlayService s = instance;
        if (s != null) s.main.post(s::applySize);
    }

    /** Called from the JS bridge whenever rank/stars change in the page. */
    static void updateState(Context c, String player, String rank, String hex, int stars, int max) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit().putString("player", player).putString("rank", rank).putString("hex", hex)
                .putInt("stars", stars).putInt("max", max).apply();
        final OverlayService s = instance;
        if (s != null) s.main.post(s::refreshBubble);
    }

    /** Redraws the bubble (e.g. the "auto-detect is running" dot changed). */
    static void refresh() {
        final OverlayService s = instance;
        if (s != null) s.main.post(s::refreshBubble);
    }

    /** Shows a short message inside the bubble (3 lines), e.g. the detected match result. */
    static void flash(final String l1, final String l2, final String l3, final int color, final long ms) {
        final OverlayService s = instance;
        if (s == null) return;
        s.main.post(new Runnable() {
            @Override
            public void run() {
                if (s.bubble == null) return;
                s.bubble.setFlash(new String[]{l1, l2, l3}, color);
                s.main.removeCallbacks(s.clearFlash);
                s.main.postDelayed(s.clearFlash, ms);
            }
        });
    }

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        installCrashLogger(this);
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();
        buildBubble();
        main.postDelayed(watchdog, WATCHDOG_MS);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Must call startForeground() quickly whenever we were started with startForegroundService()
        Notification n = buildNotification();
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }

        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("enabled", false).apply();
            removeBubble();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        refreshBubble();
        applyVisibility();
        return START_STICKY;
    }

    /** App swiped away from recents: some phones kill the service too, so ask to be started again. */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        try {
            if (isEnabled(this) && canOverlay(this)) {
                Intent i = new Intent(this, OverlayService.class);
                int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
                PendingIntent pi = Build.VERSION.SDK_INT >= 26
                        ? PendingIntent.getForegroundService(this, 2, i, PendingIntent.FLAG_UPDATE_CURRENT | imm)
                        : PendingIntent.getService(this, 2, i, PendingIntent.FLAG_UPDATE_CURRENT | imm);
                AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
                if (am != null) {
                    long at = System.currentTimeMillis() + 1500;
                    if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                    else am.set(AlarmManager.RTC_WAKEUP, at, pi);
                }
            }
        } catch (Exception ignored) {
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(watchdog);
        main.removeCallbacks(clearFlash);
        removeBubble();
        instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ---------------------------------------------------------------- notification

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Rank bubble", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;

        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | imm);

        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPi;
        if (Build.VERSION.SDK_INT >= 26) {
            stopPi = PendingIntent.getForegroundService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | imm);
        } else {
            stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | imm);
        }

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_star)
                .setContentTitle("HOK Ranked")
                .setContentText("Rank bubble is active. Tap to open the app.")
                .setContentIntent(openPi)
                .setOngoing(true)
                .addAction(0, "Stop bubble", stopPi);
        return b.build();
    }

    // ---------------------------------------------------------------- bubble

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildBubble() {
        bubble = new BubbleView(this);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        int size = dp(getSizeDp(this));
        lp = new WindowManager.LayoutParams(size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        lp.x = sp.getInt("x", dp(12));
        lp.y = sp.getInt("y", dp(160));

        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        downRawY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - downRawX;
                        float dy = e.getRawY() - downRawY;
                        if (!moved && Math.abs(dx) < slop && Math.abs(dy) < slop) return true;
                        moved = true;
                        lp.x = Math.max(0, startX + Math.round(dx));
                        lp.y = Math.max(0, startY + Math.round(dy));
                        try {
                            wm.updateViewLayout(bubble, lp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (moved) {
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                    .putInt("x", lp.x).putInt("y", lp.y).apply();
                        } else {
                            openApp();
                        }
                        return true;
                }
                return false;
            }
        });
        refreshBubble();
    }

    private void applySize() {
        int px = dp(getSizeDp(this));
        lp.width = px;
        lp.height = px;
        if (attached) {
            try {
                wm.updateViewLayout(bubble, lp);
            } catch (Exception ignored) {
            }
        }
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private void refreshBubble() {
        if (bubble == null) return;
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        String rank = sp.getString("rank", "Gold");
        String hex = sp.getString("hex", "#f3c242");
        int stars = sp.getInt("stars", 0);
        int max = sp.getInt("max", 20);
        int color;
        try {
            color = Color.parseColor(hex);
        } catch (Exception e) {
            color = 0xFFF3C242;
        }
        String starText = "★ " + stars + (max > 0 ? "/" + max : "");
        bubble.setCapturing(CaptureService.running);
        bubble.setState(rank, color, starText);
    }

    private void applyVisibility() {
        boolean show = !appInForeground && canOverlay(this);
        try {
            if (show && !attached) {
                wm.addView(bubble, lp);
                attached = true;
            } else if (!show && attached) {
                wm.removeView(bubble);
                attached = false;
            }
        } catch (Exception ignored) {
        }
    }

    private void removeBubble() {
        try {
            if (attached && bubble != null) wm.removeView(bubble);
        } catch (Exception ignored) {
        }
        attached = false;
    }

    // ---------------------------------------------------------------- view

    /** Round badge: rank name in rank color + star count. Briefly shows the detected match result. */
    static class BubbleView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rankP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint starP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float d;
        private String rank = "Gold";
        private String starText = "★ 0";
        private int color = 0xFFF3C242;
        private String[] flashLines = null;
        private int flashColor = 0xFFFFFFFF;
        private boolean capturing = false;

        BubbleView(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
            fill.setColor(0xF0060A14);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(3f * d);
            rankP.setTypeface(Typeface.DEFAULT_BOLD);
            rankP.setTextAlign(Paint.Align.CENTER);
            starP.setTypeface(Typeface.DEFAULT_BOLD);
            starP.setTextAlign(Paint.Align.CENTER);
            starP.setColor(Color.WHITE);
            dot.setColor(0xFF00FF87);
            setLayerType(LAYER_TYPE_SOFTWARE, null); // needed for the glow ring
        }

        void setState(String rank, int color, String starText) {
            this.rank = rank;
            this.color = color;
            this.starText = starText;
            invalidate();
        }

        void setFlash(String[] lines, int color) {
            this.flashLines = lines;
            this.flashColor = color;
            invalidate();
        }

        void setCapturing(boolean on) {
            this.capturing = on;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - 2f * d;
            String[] fl = flashLines;
            int col = fl != null ? flashColor : color;

            ring.setColor(col);
            ring.setShadowLayer(6f * d, 0, 0, col);
            cv.drawCircle(w / 2f, h / 2f, r, fill);
            cv.drawCircle(w / 2f, h / 2f, r, ring);

            String[] lines;
            if (fl != null) {
                lines = fl;
            } else {
                // lines: rank words (max 2 lines) + stars
                String[] words = rank.split(" ");
                String l1 = words[0];
                String l2 = null;
                if (words.length > 1) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 1; i < words.length; i++) sb.append(i > 1 ? " " : "").append(words[i]);
                    l2 = sb.toString();
                }
                lines = l2 == null ? new String[]{l1, starText} : new String[]{l1, l2, starText};
            }

            float maxW = w * 0.70f;
            float size = 13f * d;
            rankP.setTextSize(size);
            starP.setTextSize(size);
            for (String ln : lines) {
                float mw = rankP.measureText(ln);
                if (mw > maxW) size = Math.min(size, size * maxW / mw);
            }
            rankP.setTextSize(size);
            starP.setTextSize(size);
            rankP.setColor(col);

            float lh = size * 1.18f;
            float total = lh * lines.length;
            float y = h / 2f - total / 2f + lh * 0.82f;
            for (int i = 0; i < lines.length; i++) {
                Paint p = (i == lines.length - 1) ? starP : rankP;
                cv.drawText(lines[i], w / 2f, y, p);
                y += lh;
            }

            // small green dot = auto-detect is running
            if (capturing) {
                cv.drawCircle(w / 2f + r * 0.74f, h / 2f - r * 0.74f, 4.5f * d, dot);
            }
        }
    }
}
