package com.hok.ranked;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Pure-Java parsing of OCR output from the Honor of Kings screen (no Android classes,
 * so it can be unit-tested on a PC).
 *
 * What it looks for:
 *  - a big "VICTORY" / "DEFEAT" banner                       -> outcome
 *  - the player's own row on the result table (found by the in-game name typed in the app)
 *      * "MVP" tag in that row                               -> mvp
 *      * "K/D/A" numbers in that row                         -> grade C..SSS
 */
final class MatchDetector {

    static final int NONE = 0, WIN = 1, LOSE = 2;

    // KDA grade thresholds on (K + 0.7*A) / max(1, D). Edit here to tune the grading.
    static final double T_B = 1.0, T_A = 2.0, T_AP = 3.0, T_S = 4.0, T_SS = 5.5, T_SSS = 8.0;

    private static final Pattern KDA = Pattern.compile(
            "(?<!\\d)(\\d{1,2})\\s*[/|\\\\]\\s*(\\d{1,2})\\s*[/|\\\\]\\s*(\\d{1,2})(?!\\d)");

    static final class Line {
        final String text;
        final int l, t, r, b;

        Line(String text, int l, int t, int r, int b) {
            this.text = text == null ? "" : text;
            this.l = l;
            this.t = t;
            this.r = r;
            this.b = b;
        }

        int cx() {
            return (l + r) / 2;
        }

        int cy() {
            return (t + b) / 2;
        }

        int h() {
            return b - t;
        }
    }

    static final class Scan {
        int outcome = NONE;
        boolean nameFound;
        boolean mvp;
        int k = -1, d = -1, a = -1;

        boolean hasKda() {
            return k >= 0;
        }
    }

    // ------------------------------------------------------------------ main entry

    static Scan scan(List<Line> lines, int w, int h, String myName) {
        Scan s = new Scan();
        s.outcome = findOutcome(lines, h);

        String nm = norm(myName);
        if (nm.length() < 2) return s;

        List<Line> hits = new ArrayList<>();
        for (Line ln : lines) {
            if (nameMatches(norm(ln.text), nm)) hits.add(ln);
        }
        if (hits.isEmpty()) return s;

        Scan best = null;
        for (Line nl : hits) {
            Scan c = new Scan();
            c.outcome = s.outcome;
            c.nameFound = true;
            int half = Math.max((int) (nl.h() * 1.2f), (int) (h * 0.04f));
            int bestKdaDist = Integer.MAX_VALUE;
            for (Line o : lines) {
                if (Math.abs(o.cy() - nl.cy()) > half) continue;
                int dist = Math.abs(o.cx() - nl.cx());

                Matcher m = KDA.matcher(o.text);
                if (m.find() && dist < bestKdaDist) {
                    int k = Integer.parseInt(m.group(1));
                    int d = Integer.parseInt(m.group(2));
                    int a = Integer.parseInt(m.group(3));
                    if (k <= 60 && d <= 60 && a <= 90) {
                        bestKdaDist = dist;
                        c.k = k;
                        c.d = d;
                        c.a = a;
                    }
                }
                if (hasMvpToken(o.text) && dist <= w * 0.30f) c.mvp = true;
            }
            if (best == null || (c.hasKda() && !best.hasKda())) best = c;
        }
        return best;
    }

    // ------------------------------------------------------------------ outcome

    private static int findOutcome(List<Line> lines, int h) {
        int win = 0, lose = 0;
        for (Line ln : lines) {
            String txt = ln.text.trim();
            if (txt.length() > 14) continue;            // banner is a single short word
            if (ln.h() < h * 0.035f) continue;          // ...and it is BIG
            for (String tok : txt.toUpperCase(Locale.ROOT).split("[^A-Z0-9]+")) {
                if (tok.length() < 6) continue;
                if (close(tok, "VICTORY")) win++;
                else if (close(tok, "DEFEAT")) lose++;
            }
        }
        if (win > 0 && lose == 0) return WIN;
        if (lose > 0 && win == 0) return LOSE;
        return NONE;
    }

    private static boolean hasMvpToken(String text) {
        for (String tok : text.toUpperCase(Locale.ROOT).split("[^A-Z0-9]+")) {
            if (tok.equals("MVP")) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ grade

    /** C, B, A, A+, S, SS or SSS. */
    static String grade(int outcome, boolean mvp, int k, int d, int a) {
        if (k < 0) {
            // KDA could not be read: use a neutral default
            if (outcome == WIN) return mvp ? "S" : "A";
            return mvp ? "A" : "B";
        }
        double r = (k + a * 0.7) / Math.max(1, d);
        if (r >= T_SSS) return "SSS";
        if (r >= T_SS) return "SS";
        if (r >= T_S) return "S";
        if (r >= T_AP) return "A+";
        if (r >= T_A) return "A";
        if (r >= T_B) return "B";
        return "C";
    }

    // ------------------------------------------------------------------ text helpers

    static String norm(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : s.toLowerCase(Locale.ROOT).toCharArray()) {
            if (Character.isLetterOrDigit(c)) sb.append(c);
        }
        return sb.toString();
    }

    private static boolean nameMatches(String line, String name) {
        if (line.isEmpty() || name.isEmpty()) return false;
        if (name.length() >= 3 && line.contains(name)) return true;
        if (line.equals(name)) return true;
        if (name.length() >= 4 && similarity(line, name) >= 0.8) return true;
        // name shown truncated ("Shadowkil...") in the table
        return line.length() >= 4 && name.length() > line.length()
                && name.startsWith(line) && line.length() >= name.length() * 0.6;
    }

    private static boolean close(String tok, String word) {
        if (Math.abs(tok.length() - word.length()) > 1) return false;
        if (tok.charAt(0) != word.charAt(0)) return false;
        int allowed = word.length() >= 7 ? 2 : 1;   // OCR may swap look-alikes (I/l, O/0)
        return lev(tok, word) <= allowed;
    }

    private static double similarity(String a, String b) {
        int m = Math.max(a.length(), b.length());
        if (m == 0) return 1;
        return 1.0 - (double) lev(a, b) / m;
    }

    private static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }
}
