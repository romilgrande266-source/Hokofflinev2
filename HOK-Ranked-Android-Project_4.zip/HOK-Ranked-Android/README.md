# HOK Ranked – Android APK

WebView app of the **Honor of Kings Ranked System** with a floating
**rank + stars circle** (display over other apps). Tap the circle → back to the app.
Drag it to move it.

## Build in the cloud (GitHub Actions)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Push to `main` (or open **Actions → Build HOK Ranked APK → Run workflow**).
3. When it's green, open the run → **Artifacts**:
   - `HOK-Ranked-APKs-zip` → one ZIP with all APKs
   - `HOK-Ranked-APKs` → the APKs separately
   - 32-bit: `HOK-Ranked-32bit-armeabi-v7a.apk`
   - 64-bit: `HOK-Ranked-64bit-arm64-v8a.apk`
   - Both: `HOK-Ranked-universal-32bit+64bit.apk`
4. Push a tag like `v1.0.0` to also get a GitHub Release with the files.

## Using the circle
- First launch: allow **Display over other apps** (and notifications on Android 13+).
- Press Home / switch apps → the circle appears showing rank name + stars.
- Tap the circle → opens the app. Notification has a **Stop bubble** button.

## Keeping the circle alive (v8.74)
- Foreground service + sticky restart, a watchdog (every 4 s) that re-adds the circle if Android removed it,
  restart when the app is swiped away, and restart after reboot / app update.
- On first launch the app asks for **battery "Unrestricted / Don't optimize"** - please allow it
  (Settings > App Settings has a button if you skipped it). On Xiaomi/Oppo/Vivo/Samsung also enable
  **Autostart** / "Allow background activity" for HOK Ranked.

## Auto detect (real game)
Settings > **AUTO DETECT (REAL GAME)**:
1. Type your **in-game name** exactly as it appears on the result table.
2. Press **Start auto detect**, choose **Entire screen > Start now** (a green dot appears on the circle).
3. Play Honor of Kings. When the match ends the app reads the screen (on-device OCR, nothing uploaded
   or saved) and records: VICTORY / DEFEAT, your MVP tag, your K/D/A -> grade **C, B, A, A+, S, SS, SSS**.
   The circle flashes the result (WIN/LOSE, grade, SAVED).
- Grade = (K + 0.7 x A) / D :  <1 C, 1 B, 2 A, 3 A+, 4 S, 5.5 SS, 8+ SSS
  (change `T_*` in `MatchDetector.java`). If the name/KDA cannot be read: win = A (MVP win = S), lose = B.
- Stars use the same rules as the manual MATCH BATTLE SIMULATOR button.
- "Last scan" in the settings box shows what the OCR saw - use it to troubleshoot.
- Auto detect pauses while this app is on screen, and stops if you stop screen sharing.
- Android asks for screen capture permission every time you start it (Android rule).

## Edit the game
The game is `app/src/main/assets/index.html`. If you replace it with a new version,
keep the `<script>` block at the bottom ("Android bridge") – it feeds the circle.
